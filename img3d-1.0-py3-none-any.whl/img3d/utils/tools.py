import numpy as np
import cv2
import copy
import random
from scipy.spatial.transform import Rotation as R

########################################
# source /opt/ros/melodic/setup.zsh
# pip install pyyaml
# pip install pycryptodomex
# pip install gnupg
# pip install rospkg
########################################

class LazyImport:
    def __init__(self, module_name):
        self.module_name = module_name
        self.module = None
    def __getattr__(self, name):
        if self.module is None:
            self.module = __import__(self.module_name)
        return getattr(self.module, name)


def bag_data_generator(bag_path,topic):
    rosbag = LazyImport("rosbag")
    bag = rosbag.Bag(bag_path)
    for topic,msg,_ in bag.read_messages(topics=[topic]):
        if '_sensor_msgs__CompressedImage' in str(type(msg)):
            new_msg = {}
            np_arr = np.fromstring(msg.data,np.uint8)
            cv_image = cv2.imdecode(np_arr,cv2.IMREAD_COLOR)
            new_msg['image'] = cv_image
            new_msg['timestamp'] = str(msg.header.stamp)
            msg = new_msg
        yield msg

def global2car(pc,pose):
    pc = pc.T
    pc[0,:] -= pose['x']
    pc[1,:] -= pose['y']
    pc[2,:] -= pose['z']
    r_matrix = R.from_quat(np.array([pose['qx'],pose['qy'],pose['qz'],pose['qw']])).as_matrix()
    r_matrix_inv = np.linalg.inv(r_matrix)
    mat = np.matmul(r_matrix_inv,pc)
    return mat.T

def car2global(pc,pose):
    pc = pc.T
    r_matrix = R.from_quat(np.array([pose['qx'],pose['qy'],pose['qz'],pose['qw']])).as_matrix()
    mat = np.matmul(r_matrix,pc)
    mat[0,:] += pose['x']
    mat[1,:] += pose['y']
    mat[2,:] += pose['z']
    return mat.T


class PlaneObj(object):

    # Ax + By + C = z three param
    # Ax + By + Cz + D = 0 four param
    def __init__(self,points):
        self.points = points
        self._planefit()

    def _get_four_param(self):
        return [self.three_param[0],self.three_param[1],-1,self.three_param[2]]

    def _planefit(self):
        xs = []
        ys = []
        zs = []
        for i in range(len(self.points)):
            xs.append(self.points[i][0])
            ys.append(self.points[i][1])
            zs.append(self.points[i][2])
        tmp_A = []
        tmp_b = []
        for i in range(len(xs)):
            tmp_A.append([xs[i], ys[i], 1])
            tmp_b.append(zs[i])
        b = np.matrix(tmp_b).T
        A = np.matrix(tmp_A)
        fit = (A.T * A).I * A.T * b
        fit = fit.tolist()
        self.three_param = [fit[0][0],fit[1][0],fit[2][0]]
    
    def point_distance(self,point):
        Ax, By, Cz, D = self._get_four_param()
        mod_d = Ax * point[0] + By * point[1] + Cz * point[2] + D
        mod_area = np.sqrt(np.sum(np.square([Ax, By, Cz])))
        d = abs(mod_d) / mod_area
        return d

    def points_distance(self,points):
        Ax, By, Cz, D = self._get_four_param()
        mod_d = Ax * points[:,0] + By * points[:,1] + Cz * points[:,2] + D
        mod_area = np.sqrt(np.sum(np.square([Ax, By, Cz])))
        d = abs(mod_d) / mod_area
        return d
    
    def calc_fit_err(self):
        err_list = self._cal_fit_err_list(self.points)
        return np.mean(err_list),np.std(err_list)
    
    def _cal_fit_err_list(self,points):
        err_list = []
        for p in points:
            err_list.append(self.point_distance(p))
        return err_list

    
    def calc_z(self,x,y):
        return self.three_param[0]*x + self.three_param[1]*y + self.three_param[2]
    
    def calc_x(self,y,z):
        return (z - self.three_param[1]*y - self.three_param[2])/self.three_param[0]

    def calc_y(self,x,z):
        return (z - self.three_param[0]*x - self.three_param[2])/self.three_param[1]

    def erase_noisy_points_ransac(self,min_err=0.1):
        err_list = self._cal_fit_err_list(self.points)
        err = np.mean(err_list) + np.std(err_list)
        all_points = copy.deepcopy(self.points)
        all_p_num = len(all_points)
        dis_err = 0.5
        try_count = 0
        max_try_count = 100
        while err > min_err and try_count < max_try_count and len(self.points) > 100:
            self.points = random.sample(all_points,10)
            self._planefit()
            np_err_list = np.array(self._cal_fit_err_list(all_points))
            valid_mask = np_err_list< dis_err
            if np.sum(valid_mask)/all_p_num > 0.8:
                self.points = np.array(all_points)[valid_mask].tolist()
                err_list = self._cal_fit_err_list(self.points)
                err = np.mean(err_list) + np.std(err_list)
            else:
                self.points = all_points
            try_count+=1
        if err > min_err or len(self.points) < 100:
            return False,err
        return True,err
    
    def pixel_in_plane(self,u,v,pose):
        z = 1
        x = (u - pose['cx'])/pose['fx']
        y = (v - pose['cy'])/pose['fy']
        a,b,c = self.three_param
        alpha = -c/(a*x + b*y - z)
        return x*alpha,y*alpha,z*alpha
    
    def project_point(self,point):
        # https://www.baeldung.com/cs/3d-point-2d-plane
        x,y,z = point
        a,b,c,d = self._get_four_param()
        d = -d
        k = (d-a*x-b*y-c*z)/(a*a+b*b+c*c)
        p_x = x + k*a
        p_y = y + k*b
        p_z = z + k*c
        return p_x,p_y,p_z
