
def line_depth_s2d(depth_points):
    if len(depth_points) < 2:
        raise Exception(f"Not enough points")
    v_dict = {}
    for u,v,depth in depth_points:
        v_dict[v] = [u,depth]
    v_list = list(v_dict.keys())
    v_list.sort()
    pre_v = v_list[0]
    new_v_dict = {}
    for v in v_list[1:]:
        if v == pre_v + 1:
            pre_v = v
            continue
        pre_u,pre_depth = v_dict[pre_v]
        u,depth = v_dict[v]
        disp_pre = 1/pre_depth
        disp = 1/depth
        for tpv in range(pre_v+1,v):
            rate = (tpv - pre_v)/(v - pre_v)
            tp_disp = rate*(disp - disp_pre) + disp_pre
            tp_depth = 1/tp_disp
            tpu = round(rate*(u - pre_u) + pre_u)
            new_v_dict[tpv] = [tpu,tp_depth]
        pre_v = v
    v_dict.update(new_v_dict)
    all_v_list = list(v_dict.keys())
    all_v_list.sort()
    new_depth_points = []
    for v in all_v_list:
        u,depth = v_dict[v]
        new_depth_points.append([u,v,depth])
    return new_depth_points
    

class ScatterPlaneObjV3(object):

    def __init__(self,param=None):
        self.param_dict = {}
        self.param_dict[param[0]] = 1/20
        self.param_dict[param[1]] = 1/40
        self.param_dict[param[2]] = 1/60
        self.param_dict[param[3]] = 1/80
        self.param_dict[param[4]] = 1/100
        self.key_list = list(self.param_dict.keys())
        self.key_list.sort()
    
    def get_depth(self,v):
        if v < self.key_list[0]:
            a = self.key_list[1]
            b = self.key_list[0]
            disp =  (v - a)/(b - a)*(self.param_dict[b] - self.param_dict[a]) + self.param_dict[a]
            return 1/disp
        if v > self.key_list[-1]:
            a = self.key_list[-2]
            b = self.key_list[-1]
            disp =  (v - a)/(b - a)*(self.param_dict[b] - self.param_dict[a]) + self.param_dict[a]
            return 1/disp
        for i in range(len(self.key_list)):
            if self.key_list[i] > v:
                a = self.key_list[i-1]
                b = self.key_list[i]
                disp = (v - a)/(b-a)*(self.param_dict[b] - self.param_dict[a]) + self.param_dict[a]
                return 1/disp