import numpy as np
import cv2
import copy
from scipy.spatial.transform import Rotation as R

class IMG3D(object):

    def __init__(self,cam_info):
        self.cam_info = copy.deepcopy(cam_info)
        self._process_cam_info()
    
    def update_param(self,new_cam_info):
        self.cam_info = copy.deepcopy(new_cam_info)
        self._process_cam_info()
    
    def _process_cam_info(self):
        if 'IMG_W' not in self.cam_info:
            self.cam_info['IMG_W'] = 1280
        if 'IMG_H' not in self.cam_info:
            self.cam_info['IMG_H'] = 720
        T = np.array([
            [self.cam_info['fx'],0,self.cam_info['cx']],
            [0,self.cam_info['fy'],self.cam_info['cy']],
            [0,0,1]
        ])
        distortion_coefficients = np.array(self.cam_info['coeff']).reshape(5,1)
        mapx, mapy = cv2.initUndistortRectifyMap( T, distortion_coefficients, np.eye(3), T, (self.cam_info['IMG_W'],self.cam_info['IMG_H']), cv2.CV_32FC1)
        self.cam_info['mapx'] = mapx
        self.cam_info['mapy'] = mapy
        self.cam_info['T'] = T
    
    def img_remap(self,img):
        return cv2.remap(img,self.cam_info['mapx'],self.cam_info['mapy'],cv2.INTER_LINEAR, cv2.BORDER_CONSTANT)
    
    def cam2img(self,cam_pcd,skip_out_points=False):
        mat = cam_pcd.T
        matz = mat[2:3,:]
        mask = matz > 0
        mask = mask.T.flatten()
        mat_new = mat/matz
        image_np = np.matmul(self.cam_info['T'],mat_new).T
        if skip_out_points:
            inside_mask = (image_np[:,0] > 0)*(image_np[:,0] < self.cam_info['IMG_W'])*(image_np[:,1] > 0)*(image_np[:,1] < self.cam_info['IMG_H'])
            mask = inside_mask * mask
        return image_np[:,:2],mask
    
    def car2cam(self,pc):
        lidar_loc = copy.deepcopy(pc)
        lidar_loc = lidar_loc.T
        lidar_loc[0,:] -= self.cam_info['x']
        lidar_loc[1,:] -= self.cam_info['y']
        lidar_loc[2,:] -= self.cam_info['z']
        r_matrix = R.from_quat(np.array([self.cam_info['qx'],self.cam_info['qy'],self.cam_info['qz'],self.cam_info['qw']])).as_matrix()
        r_matrix_inv = np.linalg.inv(r_matrix)
        mat = np.matmul(r_matrix_inv,lidar_loc)
        return mat.T
    
    
    def gen_img_with_pcd(self,img,pcd,need_remap=True,point_size=1):
        img_remap = img
        if need_remap:
            img_remap = self.img_remap(img)
        h,w,_ = img.shape
        pc_cam = self.car2cam(pcd)
        img_arr,valid_mask = self.cam2img(pc_cam)
        for uv,coord_cam in zip(img_arr[valid_mask],pc_cam[valid_mask]):
            u,v = uv
            if u > w or u < 0 or v > h or v < 0:
                continue
            u = round(u)
            v = round(v)
            cv2.circle(img_remap,(u,v),point_size,self._get_color(coord_cam[2]),0)
        return img_remap
    
    def _get_color(self,x):
        x = round(x)*5
        x = 255*2 if x > 255*2 else x
        x = 0 if x < 0 else x
        if x < 255:
            v = x 
            return (255-v,v,0)
        if x <= 255*2:
            v = x - 255
            return (0,255-v,v)
    
    def depth2cam(self,depth_points):
        fx= self.cam_info['fx']
        fy= self.cam_info['fy']
        cx = self.cam_info['cx']
        cy = self.cam_info['cy']
        depth_p = np.array(depth_points)
        uv = depth_p[:,:2]
        depth = depth_p[:,2:3]
        xy = (uv - np.array([cx,cy]))/np.array([fx,fy])*depth
        return np.hstack((xy,depth))

    def cam2car(self,pc):
        pc = pc.T
        r_matrix = R.from_quat(np.array([self.cam_info['qx'],self.cam_info['qy'],self.cam_info['qz'],self.cam_info['qw']])).as_matrix()
        mat = np.matmul(r_matrix,pc)
        mat[0,:] += self.cam_info['x']
        mat[1,:] += self.cam_info['y']
        mat[2,:] += self.cam_info['z']
        return mat.T